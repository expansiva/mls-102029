import { telemetryQueue } from '/_102029_/l2/telemetry.js';
function traceLazy(event, details) {
    if (!globalThis.window || !window.isTraceLazy) {
        return;
    }
    console.log('[traceLazy][bff-client]', event, details ?? {});
}
/**
 * The logged user's EMAIL travels in `meta.userId` — the standard, because a display name is not unique
 * (decision of 2026-08-18). It is TELEMETRY: the server never authorizes by it (it discards the identity
 * fields of the meta on the http transport), so a wrong value costs an audit trail, never a permission.
 *
 * Read from the session cookie at REQUEST time rather than pushed in at boot: the runtime writes
 * `loginUser` (the email of the verified JWT) when the collab-auth login returns, which can happen after
 * the app mounted — a value captured at boot would stay stale, and every page reaches this client
 * directly, with nobody in between to refresh it. `setUserId` remains the explicit override for a host
 * that knows better (the Studio, a test).
 */
const SESSION_USER_COOKIE = 'loginUser';
let _userId = '';
function sessionUser() {
    try {
        const cookie = typeof document === 'undefined' ? '' : document.cookie;
        const match = new RegExp(`(?:^|;\\s*)${SESSION_USER_COOKIE}=([^;]*)`, 'u').exec(cookie);
        const value = match ? decodeURIComponent(match[1]) : '';
        return value && value !== 'anonymous' ? value : '';
    }
    catch {
        return '';
    }
}
/** The event the shell listens for to send the user back to the collab-auth login. */
export const BFF_UNAUTHENTICATED_EVENT = 'collab-bff-unauthenticated';
function notifyUnauthenticated(routine) {
    try {
        const target = typeof window === 'undefined' ? undefined : window;
        target?.dispatchEvent(new CustomEvent(BFF_UNAUTHENTICATED_EVENT, { detail: { routine } }));
    }
    catch {
        // best-effort: a host without CustomEvent still gets the normalized error above
    }
}
/** The identity to report: an explicit override wins, then the session cookie, then anonymous. */
function currentUserId() {
    return _userId || sessionUser() || 'anonymous';
}
let importedTransportUrl = null;
let importedTransport = null;
/** Explicit override (email). Empty string clears it and the session cookie takes over again. */
export function setUserId(id) {
    _userId = id;
    telemetryQueue.setUserId(id || currentUserId());
}
export function pushTelemetry(event) {
    telemetryQueue.push(event);
}
const DEFAULT_TIMEOUT_MS = 10000;
function getBffHost() {
    return globalThis;
}
function getRegisteredTransport() {
    const host = getBffHost();
    return host.window?.collabBffTransport ?? host.collabBffTransport ?? null;
}
function getTransportModuleUrl() {
    const host = getBffHost();
    return host.window?.collabBffTransportModule ?? host.collabBffTransportModule ?? null;
}
function normalizeTransportModule(mod) {
    const record = mod;
    const exported = record.default ?? record;
    if (typeof exported === 'function') {
        return {
            execBff: exported,
        };
    }
    if (exported && typeof exported === 'object' && typeof exported.execBff === 'function') {
        return exported;
    }
    if (typeof record.execBff === 'function') {
        return {
            execBff: record.execBff,
        };
    }
    throw new Error('BFF transport module must export execBff or a default transport');
}
async function resolveDirectTransport() {
    const registered = getRegisteredTransport();
    if (registered) {
        return registered;
    }
    const moduleUrl = getTransportModuleUrl();
    if (!moduleUrl) {
        return null;
    }
    if (!importedTransport || importedTransportUrl !== moduleUrl) {
        importedTransportUrl = moduleUrl;
        importedTransport = import(moduleUrl)
            .then(normalizeTransportModule)
            .catch((error) => {
            if (importedTransportUrl === moduleUrl) {
                importedTransportUrl = null;
                importedTransport = null;
            }
            throw error;
        });
    }
    return importedTransport;
}
function createRequest(routine, params, source) {
    return {
        routine,
        params,
        meta: {
            source,
            userId: currentUserId(),
            telemetry: telemetryQueue.flush(),
        },
    };
}
function unwrapDirectResult(result) {
    if (result && typeof result === 'object' && 'response' in result) {
        return result.response;
    }
    return result;
}
function withAbort(operation, signal) {
    if (signal.aborted) {
        return Promise.reject(signal.reason ?? new Error('aborted'));
    }
    return new Promise((resolve, reject) => {
        const handleAbort = () => {
            reject(signal.reason ?? new Error('aborted'));
        };
        signal.addEventListener('abort', handleAbort, { once: true });
        operation
            .then(resolve, reject)
            .finally(() => {
            signal.removeEventListener('abort', handleAbort);
        });
    });
}
function parseBffEnvelope(bodyText) {
    try {
        const parsed = JSON.parse(bodyText);
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
            return null;
        if (typeof parsed.ok !== 'boolean')
            return null;
        return parsed;
    }
    catch {
        return null;
    }
}
function httpTransportError(status, bodyText) {
    return {
        code: `HTTP_${status}`,
        message: status === 404
            ? 'Rotina ou servico nao encontrado (404).'
            : `Erro do servidor (${status}).`,
        details: bodyText.slice(0, 300),
    };
}
export async function execBff(routine, params, options = {}) {
    const controller = new AbortController();
    const cleanupTimeout = globalThis.setTimeout(() => {
        controller.abort(new Error('TIMEOUT'));
    }, options.timeoutMs ?? DEFAULT_TIMEOUT_MS);
    const signal = options.signal
        ? AbortSignal.any([controller.signal, options.signal])
        : controller.signal;
    try {
        traceLazy('request.start', {
            routine,
            timeoutMs: options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
            mode: options.mode ?? 'silent',
        });
        const directTransport = await withAbort(resolveDirectTransport(), signal);
        if (directTransport) {
            traceLazy('request.direct.start', {
                routine,
            });
            const result = await withAbort(directTransport.execBff(createRequest(routine, params, 'test'), {
                ...options,
                signal,
            }), signal);
            traceLazy('request.direct.response', {
                routine,
            });
            return unwrapDirectResult(result);
        }
        const response = await fetch('/execBff', {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
            },
            body: JSON.stringify(createRequest(routine, params, 'http')),
            signal,
        });
        traceLazy('request.response', {
            routine,
            status: response.status,
        });
        // Read the body as text first so a non-JSON response (e.g. a 404 HTML error page, common
        // when the BFF route/backend is unavailable) becomes a clean normalized error instead of
        // a "Unexpected token '<'" JSON parse exception.
        const bodyText = await response.text();
        const envelope = parseBffEnvelope(bodyText);
        if (!response.ok) {
            traceLazy('request.httpError', { routine, status: response.status });
            if (response.status === 401) {
                // The session died (or never existed). This client cannot log anyone in — the token lives in an
                // httpOnly cookie only the runtime writes — so it ANNOUNCES it and lets the shell drive the
                // redirect to collab-auth. Announced once per request, never a redirect from here: a library
                // navigating the page out from under the app would be the wrong owner for that decision.
                notifyUnauthenticated(routine);
            }
            // Domain failures (VALIDATION_ERROR, …) travel as HTTP 4xx WITH the BFF envelope in the body.
            // That envelope's error.message is the screen text. Replacing it with "Erro do servidor (400)"
            // threw the real message away and left only the status.
            if (envelope)
                return envelope;
            if (response.status === 401) {
                return {
                    ok: false,
                    data: null,
                    error: {
                        code: 'UNAUTHENTICATED',
                        message: 'Sessao expirada. Entre novamente.',
                        details: bodyText.slice(0, 300),
                    },
                };
            }
            return {
                ok: false,
                data: null,
                error: httpTransportError(response.status, bodyText),
            };
        }
        if (envelope)
            return envelope;
        traceLazy('request.badResponse', { routine });
        return {
            ok: false,
            data: null,
            error: {
                code: 'BAD_RESPONSE',
                message: 'Resposta invalida do servidor (nao-JSON).',
                details: bodyText.slice(0, 300),
            },
        };
    }
    catch (error) {
        if (signal.aborted) {
            traceLazy('request.timeout', {
                routine,
            });
            return {
                ok: false,
                data: null,
                error: {
                    code: 'TIMEOUT',
                    message: 'O servidor demorou demais para responder.',
                },
            };
        }
        traceLazy('request.networkError', {
            routine,
            message: error instanceof Error ? error.message : String(error),
        });
        return {
            ok: false,
            data: null,
            error: {
                code: 'NETWORK_ERROR',
                message: 'Servidor indisponivel ou sem conexao.',
                details: error instanceof Error ? error.message : String(error),
            },
        };
    }
    finally {
        globalThis.clearTimeout(cleanupTimeout);
    }
}
