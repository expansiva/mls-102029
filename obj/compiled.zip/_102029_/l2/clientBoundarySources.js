/// <mls fileReference="_102029_/l2/clientBoundarySources.ts" enhancement="_blank"/>
/**
 * The only L4 sources whose values cross the browser/BFF boundary.
 * Keep backend validation and frontend contract generation aligned by importing this module.
 */
export const CLIENT_BOUNDARY_SOURCES = ['userInput', 'selectedEntity', 'routeParam'];
export function isClientBoundarySource(source) {
    return typeof source === 'string' && CLIENT_BOUNDARY_SOURCES.includes(source);
}
export function clientInputPresentation(source) {
    if (source === 'userInput')
        return 'form';
    if (source === 'selectedEntity')
        return 'selection';
    if (source === 'routeParam')
        return 'route';
    return null;
}
