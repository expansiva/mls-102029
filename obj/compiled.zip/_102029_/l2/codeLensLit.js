/// <mls fileReference="_102029_/l2/codeLensLit.ts" enhancement="_blank" />
// File: CodeLens
export function setCodeLens(model1) {
    clearCodeLens(model1);
    const { model, compilerResults, storFile } = model1;
    if (!storFile || !model || !compilerResults)
        return;
    // A code lens decorates an OPEN editor. When the model was released after a compile (agent runs
    // borrow one per generated file) there is no editor left to decorate, and `getLineCount()` below
    // throws inside a promise nobody awaits — `Uncaught (in promise) Model is disposed!`.
    if (model.isDisposed?.())
        return;
    const { decorators } = compilerResults;
    if (storFile.shortName.startsWith('enhancement'))
        return;
    setCodeLensDecoratorClass(model, decorators);
    setCodeLensServiceDetails(model);
}
function clearCodeLens(model1) {
    for (let slineNr in model1.codeLens) {
        const codeLen = model1.codeLens[slineNr];
        if (codeLen[0].id === 'helpAssistant') {
            mls.l2.codeLens.removeCodeLen(model1.model, Number.parseInt(slineNr));
        }
    }
}
function setCodeLensDecoratorClass(model, decorators) {
    const objDecorators = JSON.parse(decorators);
    Object.entries(objDecorators).forEach((entrie) => {
        const decoratorInfo = entrie[1];
        if (!decoratorInfo || decoratorInfo.type !== 'ClassDeclaration')
            return;
        decoratorInfo.decorators.forEach((_decorator) => {
            if (_decorator.text.startsWith('customElement(')) {
                mls.l2.codeLens.addCodeLen(model, _decorator.line + 1, { id: 'helpAssistant', title: `customElement`, jsComm: '', refs: '_100554_pluginCodelensCustomElement' });
            }
        });
    });
}
async function setCodeLensServiceDetails(model) {
    const lines = findLinesByText(model, 'public details: IService');
    lines.forEach((line) => {
        mls.l2.codeLens.addCodeLen(model, line, { id: 'helpAssistant', title: `serviceDetails`, jsComm: '', refs: '_100554_pluginCodelensServiceDetails' });
    });
}
function findLinesByText(model, textToFind) {
    const lines = [];
    // Also guarded HERE: `setCodeLensServiceDetails` is async, so the model can be disposed between the
    // check above and this read — the residual window the entry guard cannot cover.
    if (!model || model.isDisposed?.())
        return lines;
    const lineCount = model.getLineCount();
    for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
        const lineText = model.getLineContent(lineNumber);
        if (lineText.includes(textToFind)) {
            lines.push(lineNumber);
        }
    }
    return lines;
}
