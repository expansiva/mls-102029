/// <mls fileReference="_102029_/l2/mlsDepManifest.ts" enhancement="_blank"/>
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function projectId(value) {
    if (typeof value === 'number' && Number.isFinite(value) && value > 0)
        return String(value);
    if (typeof value === 'string' && /^\d+$/.test(value.trim()))
        return value.trim();
    return '';
}
// Studio core (100554) and plugins (100555). Studio mode is a runtime capability
// (opt-in at execution time), not an app-owned dependency — so it joins the
// client closure here, the same way runtimeProject does. Do not add these to
// l5/config.json.workspaceDependencies (that list is how the host resolves an
// agent) or to config.projects (that is what build.mjs compiles into the bundle).
const STUDIO_WORKSPACE_IDS = ['100554', '100555'];
/** Sorted unique ids: l5 list ∪ each master's runtimeProject ∪ the Studio pair ∪ 102041 when 102033 is present. */
export function buildMlsDepWorkspaceIds(l5Config, l5Project) {
    const ids = new Set();
    const listed = isRecord(l5Config) ? l5Config.workspaceDependencies : undefined;
    if (Array.isArray(listed)) {
        for (const item of listed) {
            const id = projectId(item);
            if (id)
                ids.add(id);
        }
    }
    const masters = isRecord(l5Project) && isRecord(l5Project.masters) ? l5Project.masters : {};
    for (const side of ['frontend', 'backend']) {
        const signature = isRecord(masters[side]) ? masters[side] : undefined;
        const id = projectId(signature?.runtimeProject);
        if (id)
            ids.add(id);
    }
    for (const id of STUDIO_WORKSPACE_IDS)
        ids.add(id);
    // 102041 is the studio site (navs/page) the master frontend loads at runtime
    // via import(`/_${STUDIO_PROJECT}_/…`). Not a static specifier, so it joins
    // here whenever 102033 is in the closure — same reason 100554/100555 join.
    // Do not add it to l5/config.json.workspaceDependencies.
    if (ids.has('102033'))
        ids.add('102041');
    return [...ids].sort((left, right) => Number(left) - Number(right));
}
export function serializeMlsDepJson(ids) {
    const manifest = { workspaceDependencies: [...ids] };
    return `${JSON.stringify(manifest, null, 2)}\n`;
}
export function mlsDepJsonContents(l5Config, l5Project) {
    return serializeMlsDepJson(buildMlsDepWorkspaceIds(l5Config, l5Project));
}
export function mlsDepPathFromL5ConfigPath(configPath) {
    return configPath.replace(/l5[/\\]config\.json$/i, 'mlsDep.json');
}
/** Byte-identical content is a no-op so a second merge does not dirty the worktree. */
export function emitMlsDepJson(destPath, l5Config, l5Project, io) {
    let existing = null;
    if (io.read) {
        try {
            existing = io.read(destPath);
        }
        catch {
            existing = null;
        }
    }
    const next = mlsDepJsonContents(l5Config, l5Project);
    if (existing === next)
        return false;
    io.write(destPath, next);
    return true;
}
/**
 * Host-only write of `<client>/mlsDep.json`. No-op in the browser (no diskPath / no write
 * capability). Branches on capability, not on host name.
 */
export function emitMlsDepJsonIfHostDisk(project, l5Config, l5Project) {
    if (!project)
        return false;
    // `stor` is kept whole and `diskPath` is called AS A METHOD: on the CLI host it is a
    // class method over a private field, so a detached `const fn = …; fn(info)` throws,
    // the catch below swallows it and the manifest is never written — the VM build then
    // fails to resolve the closure (the 328-error run of 02/09). Measured 02/09.
    const stor = globalThis.mls?.stor;
    const diskPath = stor?.diskPath;
    const deno = globalThis.Deno;
    if (typeof diskPath !== 'function' || typeof deno?.writeTextFileSync !== 'function')
        return false;
    let dest;
    try {
        dest = mlsDepPathFromL5ConfigPath(stor.diskPath({
            project, level: 5, folder: '', shortName: 'config', extension: '.json',
        }));
    }
    catch {
        return false;
    }
    return emitMlsDepJson(dest, l5Config, l5Project, {
        read: typeof deno.readTextFileSync === 'function' ? (path) => deno.readTextFileSync(path) : undefined,
        write: (path, source) => deno.writeTextFileSync(path, source),
    });
}
