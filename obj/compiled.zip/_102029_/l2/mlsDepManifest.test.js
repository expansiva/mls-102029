/// <mls fileReference="_102029_/l2/mlsDepManifest.test.ts" enhancement="_blank"/>
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
import test from 'node:test';
import assert from 'node:assert/strict';
import { buildMlsDepWorkspaceIds, emitMlsDepJson, emitMlsDepJsonIfHostDisk, mlsDepJsonContents, mlsDepPathFromL5ConfigPath, serializeMlsDepJson, } from '/_102029_/l2/mlsDepManifest.js';
const L5_CONFIG = {
    workspaceDependencies: ['102047', '102020', '102021', '102027', '102029', '102036', '102025'],
};
const L5_PROJECT = {
    masters: {
        backend: { runtimeProject: 102034 },
        frontend: { runtimeProject: 102033 },
    },
};
test('mlsDep ids are the l5 list union the two runtimeProject masters', () => {
    assert.deepEqual(buildMlsDepWorkspaceIds(L5_CONFIG, L5_PROJECT), ['102020', '102021', '102025', '102027', '102029', '102033', '102034', '102036', '102047']);
});
test('runtimeProject is added even when the l5 list omitted it', () => {
    const ids = buildMlsDepWorkspaceIds({ workspaceDependencies: ['102047', '102020'] }, L5_PROJECT);
    assert.ok(ids.includes('102033'));
    assert.ok(ids.includes('102034'));
    assert.ok(ids.includes('102047'));
    assert.ok(ids.includes('102020'));
});
test('masters as strings and missing l5 list still emit the runtime projects', () => {
    assert.deepEqual(buildMlsDepWorkspaceIds({}, { masters: { frontend: { runtimeProject: '102033' }, backend: { runtimeProject: '102034' } } }), ['102033', '102034']);
});
test('serialize is stable: two calls with the same inputs are byte-identical', () => {
    const first = mlsDepJsonContents(L5_CONFIG, L5_PROJECT);
    const second = mlsDepJsonContents(L5_CONFIG, L5_PROJECT);
    assert.equal(second, first);
    assert.equal(first, serializeMlsDepJson(buildMlsDepWorkspaceIds(L5_CONFIG, L5_PROJECT)));
    assert.match(first, /\n$/);
});
test('emitMlsDepJson does not write when the bytes already match', () => {
    const dest = '/tmp/mlsDep.json';
    const expected = mlsDepJsonContents(L5_CONFIG, L5_PROJECT);
    let writes = 0;
    const wrote = emitMlsDepJson(dest, L5_CONFIG, L5_PROJECT, {
        read: () => expected,
        write: () => { writes += 1; },
    });
    assert.equal(wrote, false);
    assert.equal(writes, 0);
});
test('emitMlsDepJson writes once when the file is missing, then no-ops', () => {
    const files = new Map();
    const io = {
        read: (path) => {
            const value = files.get(path);
            if (value === undefined)
                throw new Error('ENOENT');
            return value;
        },
        write: (path, source) => { files.set(path, source); },
    };
    const dest = 'mlsDep.json';
    assert.equal(emitMlsDepJson(dest, L5_CONFIG, L5_PROJECT, io), true);
    const first = files.get(dest);
    assert.ok(first);
    assert.equal(emitMlsDepJson(dest, L5_CONFIG, L5_PROJECT, io), false);
    assert.equal(files.get(dest), first);
});
test('mlsDep path sits at the project root next to l5/config.json', () => {
    assert.equal(mlsDepPathFromL5ConfigPath('/data/mls-base/mls-102047/l5/config.json'), '/data/mls-base/mls-102047/mlsDep.json');
    assert.equal(mlsDepPathFromL5ConfigPath('C:\\mls-base\\mls-102047\\l5\\config.json'), 'C:\\mls-base\\mls-102047\\mlsDep.json');
});
// The host's diskPath is a class method over a private field. Detaching it throws, the
// catch swallows it, and mlsDep.json is never written — the VM build then cannot resolve
// the dependency closure. Measured on the CLI host 02/09/2026.
void test('emitMlsDepJsonIfHostDisk calls diskPath as a method (host class, private field)', () => {
    var _HostStor_base;
    class HostStor {
        constructor() {
            _HostStor_base.set(this, '/data/mls-base');
        }
        diskPath(info) {
            return `${__classPrivateFieldGet(this, _HostStor_base, "f")}/mls-${info.project}/l5/${info.shortName}${info.extension}`;
        }
    }
    _HostStor_base = new WeakMap();
    const g = globalThis;
    const prevMls = g.mls;
    const prevDeno = g.Deno;
    const written = [];
    g.mls = { stor: new HostStor() };
    g.Deno = { writeTextFileSync: (path, data) => { written.push({ path, data }); } };
    try {
        const wrote = emitMlsDepJsonIfHostDisk(102043, { workspaceDependencies: ['102043', '102020'] }, { masters: { backend: { runtimeProject: 102034 }, frontend: { runtimeProject: 102033 } } });
        assert.equal(wrote, true);
        assert.equal(written.length, 1);
        assert.equal(written[0].path, '/data/mls-base/mls-102043/mlsDep.json');
        assert.deepEqual(JSON.parse(written[0].data).workspaceDependencies, ['102020', '102033', '102034', '102043']);
    }
    finally {
        g.mls = prevMls;
        g.Deno = prevDeno;
    }
});
