/// <mls fileReference="_102029_/l2/studioDefs.ts" enhancement="_blank" />
const STUDIO_DEFS_KEY = 'studio_defs';
const PROVIDERS = ['github', 'gitlab'];
const LEGACY_KEY = {
    github: 'keyGitHub',
    gitlab: 'keyGitLab',
};
function storageBox() {
    const storage = globalThis.localStorage;
    if (!storage) {
        console.error('[studioDefs] localStorage is unavailable');
        return null;
    }
    return storage;
}
function tokenOf(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return null;
    const token = value.token;
    if (typeof token !== 'string' || token.length === 0)
        return null;
    return token;
}
function parseStored(raw) {
    let parsed;
    try {
        parsed = JSON.parse(raw);
    }
    catch (error) {
        const name = error instanceof Error ? error.name : 'unknown';
        console.error(`[studioDefs] studio_defs is not valid JSON (${name})`);
        return {};
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        console.error('[studioDefs] studio_defs is not a JSON object');
        return {};
    }
    const record = parsed;
    const defs = {};
    for (const provider of PROVIDERS) {
        const token = tokenOf(record[provider]);
        if (token)
            defs[provider] = { token };
    }
    return defs;
}
function persist(storage, defs) {
    if (!defs.github && !defs.gitlab) {
        storage.removeItem(STUDIO_DEFS_KEY);
        return;
    }
    storage.setItem(STUDIO_DEFS_KEY, JSON.stringify(defs));
}
function load(storage) {
    const raw = storage.getItem(STUDIO_DEFS_KEY);
    const defs = raw === null ? {} : parseStored(raw);
    let migrated = false;
    for (const provider of PROVIDERS) {
        if (defs[provider])
            continue;
        const legacy = storage.getItem(LEGACY_KEY[provider]);
        if (!legacy)
            continue;
        defs[provider] = { token: legacy };
        storage.removeItem(LEGACY_KEY[provider]);
        migrated = true;
    }
    if (migrated)
        persist(storage, defs);
    return defs;
}
export function readStudioDefs() {
    const storage = storageBox();
    if (!storage)
        return {};
    return load(storage);
}
export function writeStudioProviderToken(provider, token) {
    const storage = storageBox();
    if (!storage)
        return;
    const defs = load(storage);
    defs[provider] = { token };
    persist(storage, defs);
}
export function removeStudioProvider(provider) {
    const storage = storageBox();
    if (!storage)
        return;
    const defs = load(storage);
    delete defs[provider];
    storage.removeItem(LEGACY_KEY[provider]);
    persist(storage, defs);
}
