/// <mls fileReference="_102029_/l2/utils.ts" enhancement="_blank" />
export function getPath(widget) {
    return mls.actual[0].setFullName(widget).getStorFileBase();
}
export function convertTagToFileName(tag) {
    const parts = tag.split('--');
    const namePart = parts.pop() || '';
    const folder = parts.join('/').replace(/-(.)/g, (_, letter) => letter.toUpperCase());
    const regex = /(.+)-(\d+)$/;
    const match = namePart.match(regex);
    if (!match)
        return;
    const [, rest, number] = match;
    const shortName = rest.replace(/-(.)/g, (_, letter) => letter.toUpperCase());
    return {
        shortName,
        project: +number,
        folder
    };
}
export function convertFileNameToTag(info) {
    const { shortName, project, folder = '' } = info;
    const kebabName = shortName.replace(/([A-Z])/g, '-$1').toLowerCase();
    const baseName = `${kebabName}-${project}`;
    const folderPrefix = folder ? folder.replace(/([A-Z])/g, '-$1').toLowerCase().replace(/\//g, '--') + '--' : '';
    return `${folderPrefix}${baseName}`;
}
/** Lowest project id the platform assigns — anything below is not a real project. */
const MIN_PROJECT_ID = 100000;
function getStudioBoot() {
    return globalThis.collabBoot;
}
/**
 * Where the studio chrome is running:
 * - 'studio'       — on.collab.codes: the full IDE, every org/project.
 * - 'studioClient' — the client server's app page: the studio runs embedded and is
 *                    scoped to the single project that app belongs to.
 *
 * The client server (startServer, mls-102034) injects window.collabBoot on every app
 * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
 * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
 */
export function getStudioRunMode() {
    return getStudioBoot() ? 'studioClient' : 'studio';
}
export function isStudioClient() {
    return getStudioRunMode() === 'studioClient';
}
/**
 * The single project the studio-client is pinned to; undefined in 'studio' mode.
 * collabBoot.projectId is authoritative (cbeMiniCfe feeds mls.setActualProject from it);
 * mls.actualProject is the fallback when the boot payload carries no usable id.
 */
export function getStudioScopeProject() {
    const boot = getStudioBoot();
    if (!boot)
        return undefined;
    const fromBoot = Number(boot.projectId);
    if (Number.isFinite(fromBoot) && fromBoot >= MIN_PROJECT_ID)
        return fromBoot;
    const fromMls = Number(globalThis.mls?.actualProject);
    return Number.isFinite(fromMls) && fromMls >= MIN_PROJECT_ID ? fromMls : undefined;
}
export function setErrorOnModel(model, line, startColumn, endColumn, message, severity) {
    const lineIndent = getLineIndent(model, line);
    const markerOptions = {
        severity,
        message,
        startLineNumber: line,
        startColumn: startColumn + lineIndent,
        endLineNumber: line,
        endColumn: endColumn + lineIndent,
    };
    monaco.editor.setModelMarkers(model, 'markerSource', [markerOptions]);
}
function getLineIndent(model, lineNumber) {
    if (model) {
        var lineContent = model.getLineContent(lineNumber);
        var match = lineContent.match(/^\s*/);
        return match ? match[0].length : 0;
    }
    return 0;
}
